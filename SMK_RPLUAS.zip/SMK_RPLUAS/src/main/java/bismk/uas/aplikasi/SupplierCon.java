package bismk.uas.aplikasi;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import java.io.IOException;


public class SupplierCon {
    @FXML
    private Button CancelButton;
    @FXML
    private TextField enterIDSUP;
    @FXML
    private TextField enterSUPName;
    @FXML
    private TextField enterSUPContactInfo;
    @FXML
    private TextField enterSUPTelpNum;
    @FXML
    private  TextField enterSUPAdress;
    @FXML
    private  TextField entertype;
    @FXML
    private Button NewdatButton;




    @FXML
    private void hanldeCancel_Return() throws IOException {
        Stage stage = (Stage) CancelButton.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Dashboard.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
    }

    @FXML
    private void  handle_newdata() throws IOException{
        Stage stage =(Stage) NewdatButton.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("supplier.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
    }

    @FXML
    private void handleSaveSupplier() throws IOException{
        String SupplierID = enterIDSUP.getText();
        String SupplierName = enterSUPName.getText();
        String SupplierContact = enterSUPContactInfo.getText();
        String SuplierTelp = enterSUPTelpNum.getText();
        String SupplierAddress = enterSUPAdress.getText();
        String SupplierItemType = entertype.getText();


        if (SupplierID.isEmpty() || SupplierName.isEmpty() || SupplierContact.isEmpty() || SuplierTelp.isEmpty() || SupplierAddress.isEmpty()) {
            // Handle empty fields (show an alert or message to the user)
            System.out.println("Please fill in all fields");
            return;
        }

        String insertSQL = "INSERT INTO supplier (supplierID, supplier_name, contactinfo, telp, address, type) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {

            pstmt.setString(1, SupplierID);
            pstmt.setString(2, SupplierName);
            pstmt.setString(3, SupplierContact);
            pstmt.setString(4, SuplierTelp);
            pstmt.setString(5, SupplierAddress);
            pstmt.setString(6, SupplierItemType);

            pstmt.executeUpdate();
            System.out.println("Product saved successfully");
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
}
