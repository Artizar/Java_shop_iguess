package bismk.uas.aplikasi;
import javafx.fxml.FXML;
import javafx.stage.Stage;
import javafx.scene.control.Button;


public class LoginController {
   int id = 1;
   int pass = 1010;
}
