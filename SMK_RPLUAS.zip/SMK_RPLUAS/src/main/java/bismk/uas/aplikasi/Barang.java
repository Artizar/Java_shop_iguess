package bismk.uas.aplikasi;

public class Barang {

    int Id_barang;
    String NamaBarang;
    String TipeBarang;
    double Berat;
    double Harga;
    String KdSuplier;

    public Barang(int id_barang, String namaBarang, String tipeBarang, double berat, double harga, String kdSuplier) {
        Id_barang = id_barang;
        NamaBarang = namaBarang;
        TipeBarang = tipeBarang;
        Berat = berat;
        Harga = harga;
        KdSuplier = kdSuplier;
    }
}





