package bismk.uas.aplikasi;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class HelloController {

    @FXML
    private Button tombolCancel;

    @FXML
    private Button tombolSignin;

    @FXML
    private Button signup;

    @FXML
    private TextField enterUserID;

    @FXML
    private TextField enterUserPassword;

    @FXML
    private void handleCancelButtonAction() {
        Stage stage = (Stage) tombolCancel.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void hanldeSignup() throws IOException {
        Stage stage = (Stage) signup.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Resgister.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
    }

    @FXML
    private void handleSigninButtonAction() {
        String userID = enterUserID.getText();
        String userPassword = enterUserPassword.getText();

        if (authenticate(userID, userPassword)) {
            try {
                Stage stage = (Stage) tombolSignin.getScene().getWindow();
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Dashboard.fxml"));
                Scene scene = new Scene(fxmlLoader.load());
                stage.setScene(scene);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            showAlert("Authentication Failed", "Incorrect username or password.");
        }
    }

    private boolean authenticate(String userID, String userPassword) {
        String query = "SELECT * FROM user WHERE name = ? AND password = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, userID);
            pstmt.setString(2, userPassword);

            ResultSet rs = pstmt.executeQuery();
            return rs.next(); // If a record is found, authentication is successful
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
