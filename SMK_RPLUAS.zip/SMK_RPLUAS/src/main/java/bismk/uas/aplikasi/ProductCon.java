package bismk.uas.aplikasi;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ProductCon {
    @FXML
    private Button CancelButton;

    @FXML
    private TextField enterProductID;
    @FXML
    private TextField enterProductName;
    @FXML
    private TextField enterDescription;
    @FXML
    private TextField enterPrice;
    @FXML
    private TextField enterQuantity;
    @FXML
    private Button NewdatButton;

    @FXML
    private void hanldeCancel_Return() throws IOException {
        Stage stage = (Stage) CancelButton.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Dashboard.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
    }

    @FXML
    private void  handle_newdata() throws IOException{
        Stage stage =(Stage) NewdatButton.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("supplier.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
    }

    @FXML
    private void handleSaveProduct() {
        String productID = enterProductID.getText();
        String productName = enterProductName.getText();
        String description = enterDescription.getText();
        String price = enterPrice.getText();
        String quantity = enterQuantity.getText();

        if (productID.isEmpty() || productName.isEmpty() || description.isEmpty() || price.isEmpty() || quantity.isEmpty()) {
            // Handle empty fields (show an alert or message to the user)
            System.out.println("Please fill in all fields");
            return;
        }

        String insertSQL = "INSERT INTO product (product_id, name, description, price, quantity) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {

            pstmt.setString(1, productID);
            pstmt.setString(2, productName);
            pstmt.setString(3, description);
            pstmt.setString(4, price);
            pstmt.setString(5, quantity);

            pstmt.executeUpdate();
            System.out.println("Product saved successfully");
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle SQL exception (show an alert or message to the user)
        }
    }
}
