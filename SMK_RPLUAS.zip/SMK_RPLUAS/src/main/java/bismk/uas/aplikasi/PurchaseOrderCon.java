package bismk.uas.aplikasi;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PurchaseOrderCon {
    @FXML
    private Button CancelButton;
    @FXML
    private TextField ordernumber;
    @FXML
    private DatePicker date;
    @FXML
    private TextField telp;
    @FXML
    private TextField price;
    @FXML
    private TextField Suppliername;
    @FXML
    private TextField productname;
    @FXML
    private TextField howmany;
    @FXML
    private TextField address;

    @FXML
    private Button NewdatButton;

    @FXML
    private void hanldeCancel_Return() throws IOException {
        Stage stage = (Stage) CancelButton.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Dashboard.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
    }

    @FXML
    private void  handle_newdata() throws IOException{
        Stage stage =(Stage) NewdatButton.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Purchase_order.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
    }

    @FXML
    private void handleSavePurchaseOrder() {
        String orderNumber = ordernumber.getText();
        String orderDate = (date.getValue() != null) ? date.getValue().toString() : "";
        String phoneNumber = telp.getText();
        String orderPrice = price.getText();
        String supplierName = Suppliername.getText();
        String productName = productname.getText();
        String quantity = howmany.getText();
        String supplierAddress = address.getText();

        if (orderNumber.isEmpty() || orderDate.isEmpty() || phoneNumber.isEmpty() || orderPrice.isEmpty() ||
                supplierName.isEmpty() || productName.isEmpty() || quantity.isEmpty() || supplierAddress.isEmpty()) {
            // Handle empty fields (show an alert or message to the user)
            System.out.println("Please fill in all fields");
            return;
        }

        String insertSQL = "INSERT INTO orderpurchase (order_number, order_date, number, price, supplier_name, product_name, quantity, address) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {

            pstmt.setString(1, orderNumber);
            pstmt.setString(2, orderDate);
            pstmt.setString(3, phoneNumber);
            pstmt.setString(4, orderPrice);
            pstmt.setString(5, supplierName);
            pstmt.setString(6, productName);
            pstmt.setString(7, quantity);
            pstmt.setString(8, supplierAddress);

            pstmt.executeUpdate();
            System.out.println("Purchase order saved successfully");
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle SQL exception (show an alert or message to the user)
        }
    }
}
