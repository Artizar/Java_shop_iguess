package bismk.uas.aplikasi;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegisterCON {
    @FXML
    private TextField username;

    @FXML
    private TextField password;

    @FXML
    private TextField email;

    @FXML
    private Button save;

    @FXML
    private Button cancel;

    @FXML
    private void handleSaveButtonAction() {
        String user = username.getText();
        String pass = password.getText();
        String mail = email.getText();

        if (user.isEmpty() || pass.isEmpty() || mail.isEmpty()) {
            showAlert("Validation Error", "Please enter all fields.");
            return;
        }

        if (registerUser(user, pass, mail)) {
            showAlert("Registration Successful", "User registered successfully.");
            clearFields();
            loadLoginScreen();
        } else {
            showAlert("Registration Failed", "Could not register user.");
        }
    }

    @FXML
    private void handleCancelButtonAction() {
        Stage stage = (Stage) cancel.getScene().getWindow();
        stage.close();
    }

    private boolean registerUser(String user, String pass, String mail) {
        String query = "INSERT INTO user (name, password, email) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, user);
            pstmt.setString(2, pass);
            pstmt.setString(3, mail);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void clearFields() {
        username.clear();
        password.clear();
        email.clear();
    }

    private void loadLoginScreen() {
        try {
            Stage stage = (Stage) save.getScene().getWindow();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("login.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            stage.setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
