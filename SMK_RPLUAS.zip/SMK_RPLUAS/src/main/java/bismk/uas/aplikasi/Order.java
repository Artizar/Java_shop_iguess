package bismk.uas.aplikasi;

import java.util.Date;

public class Order {
    private int orderId;
    private Date orderDate;
    private int customerId;
    private String status;
    private double totalAmount;

    public Order(int orderId, Date orderDate, int customerId, String status, double totalAmount) {
        this.orderId = orderId;
        this.orderDate = orderDate;
        this.customerId = customerId;
        this.status = status;
        this.totalAmount = totalAmount;
    }

    public int getOrderId() {
        return orderId;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public double getTotalAmount() {
        return totalAmount;
    }
}
