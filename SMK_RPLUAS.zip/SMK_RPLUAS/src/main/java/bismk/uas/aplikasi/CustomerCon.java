package bismk.uas.aplikasi;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CustomerCon {
    @FXML
    private Button CancelButton;
    @FXML
    private TextField enterID;
    @FXML
    private TextField entername;
    @FXML
    private TextField enteraddress;
    @FXML
    private TextField enterphonenumber;
    @FXML
    private  TextField enteremail;

    @FXML
    private void hanldeCancel_Return() throws IOException {
        Stage stage = (Stage) CancelButton.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Dashboard.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
    }


    @FXML
    private void handleSaveCustomer() throws IOException{
        String CustomerID = enterID.getText();
        String CustomerName = entername.getText();
        String CustomerEmail = enteremail.getText();
        String CustomerTelp = enterphonenumber.getText();
        String CustomerAddress = enteraddress.getText();


        if (CustomerID.isEmpty() || CustomerName.isEmpty() || CustomerAddress.isEmpty() || CustomerTelp.isEmpty() || CustomerEmail.isEmpty()) {
            // Handle empty fields (show an alert or message to the user)
            System.out.println("Please fill in all fields");
            return;
        }

        String insertSQL = "INSERT INTO customer (customer_id, name, email, phone, address) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {

            pstmt.setString(1, CustomerID);
            pstmt.setString(2, CustomerName);
            pstmt.setString(3, CustomerEmail);
            pstmt.setString(4, CustomerTelp);
            pstmt.setString(5, CustomerAddress);

            pstmt.executeUpdate();
            System.out.println("Product saved successfully");
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
}
