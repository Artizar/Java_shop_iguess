package bismk.uas.aplikasi;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;


public class DasgboardCon {
    @FXML
    private Button ButtonLogout;

    @FXML
    private Button ButtonList;
    @FXML
    private Button ButtonProduct;
    @FXML
    private Button CustomerButton;
    @FXML
    private Button SupplierButton;
    @FXML
    private Button ButtonPurchaseOrder;
    @FXML
    private Button ButtonTransaction;
    @FXML
    private Button ButtonMaster_questionmark;
    @FXML
    private Button InvenReFormButton;

    @FXML
    private void hanldeLogoutaction() throws IOException {
        Stage stage = (Stage) ButtonLogout.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Login.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);

    }

    @FXML
    private void handleList() throws IOException{
        Stage stage = (Stage) ButtonList.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Invenlist.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
    }

    @FXML
    private void handleProduct() throws IOException{
        Stage stage = (Stage) ButtonProduct.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Product.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
    }

    @FXML
    private void handleCustomer() throws IOException{
        Stage stage = (Stage) CustomerButton.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Customer.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
    }

    @FXML
    private void handleSupplier() throws IOException{
        Stage stage = (Stage) SupplierButton.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Supplier.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
    }

    @FXML
    private void handlePUR() throws IOException{
        Stage stage = (Stage) ButtonPurchaseOrder.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Purchase_order.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
    }

    @FXML
    private void handleOrder() throws IOException{
        Stage stage = (Stage) ButtonTransaction.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Inventaris.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
    }

    @FXML
    private void handleCheckOut() throws IOException{
        Stage stage = (Stage) ButtonMaster_questionmark.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("invenCheckout.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
    }
}
