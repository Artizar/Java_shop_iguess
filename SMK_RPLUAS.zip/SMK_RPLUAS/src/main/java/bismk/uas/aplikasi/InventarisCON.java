package bismk.uas.aplikasi;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

public class InventarisCON {

    @FXML
    private Button CancelButton;

    @FXML
    private TableView<OrderItem> orderItemTable;

    @FXML
    private TableColumn<OrderItem, Integer> orderItemIdColumn;

    @FXML
    private TableColumn<OrderItem, Integer> orderIdColumn;

    @FXML
    private TableColumn<OrderItem, Integer> productIdColumn;

    @FXML
    private TableColumn<OrderItem, Integer> quantityColumn;

    @FXML
    private TableColumn<OrderItem, Double> priceColumn;

    @FXML
    private void initialize() {
        orderItemIdColumn.setCellValueFactory(new PropertyValueFactory<>("orderItemId"));
        orderIdColumn.setCellValueFactory(new PropertyValueFactory<>("orderId"));
        productIdColumn.setCellValueFactory(new PropertyValueFactory<>("productId"));
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        loadOrderItemData();
    }

    private void loadOrderItemData() {
        String query = "SELECT * FROM orderitem";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                int orderItemId = rs.getInt("order_item_id");
                int orderId = rs.getInt("order_id");
                int productId = rs.getInt("product_id");
                int quantity = rs.getInt("quantity");
                double price = rs.getDouble("price");

                OrderItem orderItem = new OrderItem(orderItemId, orderId, productId, quantity, price);
                orderItemTable.getItems().add(orderItem);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void hanldeCancel_Return() throws IOException {
        Stage stage = (Stage) CancelButton.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Dashboard.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
    }
}
